import { Home, BookOpen, BarChart3, User, MessageCircle } from "lucide-react";
import { Button } from "./ui/button";

const navItems = [
  { icon: Home, label: "Home", active: true },
  { icon: BookOpen, label: "Lessons", active: false },
  { icon: BarChart3, label: "Progress", active: false },
  { icon: MessageCircle, label: "Community", active: false },
  { icon: User, label: "Profile", active: false },
];

export function BottomNavigation() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 glass-strong border-t border-white/20 shadow-2xl">
      <div className="flex items-center justify-around py-2 px-4 max-w-md mx-auto">
        {navItems.map((item) => (
          <Button
            key={item.label}
            variant="ghost"
            size="sm"
            className={`flex flex-col items-center gap-1 p-2 h-auto rounded-lg ${
              item.active 
                ? "text-white bg-white/20" 
                : "text-white/70 hover:text-white hover:bg-white/10"
            }`}
          >
            <item.icon className="h-5 w-5" />
            <span className="text-xs">{item.label}</span>
          </Button>
        ))}
      </div>
    </nav>
  );
}