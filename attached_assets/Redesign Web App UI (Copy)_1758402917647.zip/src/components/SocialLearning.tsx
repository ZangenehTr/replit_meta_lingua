import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Switch } from "./ui/switch";
import { Users, MessageCircle, Trophy } from "lucide-react";

export function SocialLearning() {
  return (
    <Card className="solid-card relative overflow-hidden">
      <div className="absolute top-0 left-0 w-16 h-16 bg-gradient-to-br from-pink-400 to-transparent opacity-20 rounded-full"></div>
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-gradient-to-r from-pink-400 to-purple-500 rounded-2xl shadow-lg">
              <Users className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-card-foreground text-lg">Ready to mingle!</h3>
              <p className="text-sm text-muted-foreground font-medium">Connect with your learning besties</p>
            </div>
          </div>
          <Switch className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-pink-500 data-[state=checked]:to-purple-500" />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="solid-card-elevated rounded-2xl p-4 text-center bg-gradient-to-br from-blue-50 to-purple-50 hover:scale-105 transition-transform duration-300">
            <MessageCircle className="h-8 w-8 text-blue-600 mx-auto mb-3" />
            <div className="text-2xl font-bold text-card-foreground mb-1">24</div>
            <div className="text-sm text-muted-foreground font-bold">Study Buddies</div>
          </div>
          <div className="solid-card-elevated rounded-2xl p-4 text-center bg-gradient-to-br from-yellow-50 to-orange-50 hover:scale-105 transition-transform duration-300">
            <Trophy className="h-8 w-8 text-orange-600 mx-auto mb-3" />
            <div className="text-2xl font-bold text-card-foreground mb-1">8</div>
            <div className="text-sm text-muted-foreground font-bold">Team Battles</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}