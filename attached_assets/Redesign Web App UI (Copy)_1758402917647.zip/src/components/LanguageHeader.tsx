import { Bell, Menu, User } from "lucide-react";
import { Button } from "./ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "./ui/avatar";

export function LanguageHeader() {
  return (
    <header className="glass-strong text-white px-4 py-4 sticky top-0 z-50">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold">Meta Lingua</h1>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 relative">
            <Bell className="h-5 w-5" />
            <div className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full"></div>
          </Button>
          
          <Avatar className="h-8 w-8">
            <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b612b786?w=32&h=32&fit=crop&crop=face" />
            <AvatarFallback className="glass text-white">AM</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}