import { BookOpen, ArrowRight } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";

export function LearningCard() {
  return (
    <Card className="glass-strong text-white border-white/30 shadow-2xl bg-gradient-to-br from-green-500/20 to-green-600/20">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold mb-2">Good Learning</h3>
            <p className="text-white/80 text-sm mb-4">
              Continue your language journey with interactive lessons and real-world practice.
            </p>
          </div>
          <div className="ml-4">
            <div className="w-12 h-12 glass rounded-full flex items-center justify-center">
              <BookOpen className="h-6 w-6" />
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="text-sm text-white/80">
            Next lesson: <span className="font-medium text-white">Unit 3.2</span>
          </div>
          <Button 
            variant="secondary" 
            size="sm" 
            className="bg-white/20 text-white hover:bg-white/30 backdrop-blur-sm border border-white/30 rounded-full"
          >
            Continue
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}