import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "./ui/avatar";
import { Badge } from "./ui/badge";

const activities = [
  {
    id: 1,
    user: "Sarah Chen",
    action: "completed project",
    target: "Website Redesign",
    time: "2 hours ago",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=32&h=32&fit=crop&crop=face",
    initials: "SC",
    type: "success"
  },
  {
    id: 2,
    user: "Mike Johnson",
    action: "created new task",
    target: "Database Migration",
    time: "4 hours ago",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=32&h=32&fit=crop&crop=face",
    initials: "MJ",
    type: "info"
  },
  {
    id: 3,
    user: "Emma Wilson",
    action: "updated deadline for",
    target: "Mobile App Release",
    time: "6 hours ago",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=32&h=32&fit=crop&crop=face",
    initials: "EW",
    type: "warning"
  },
  {
    id: 4,
    user: "Alex Rodriguez",
    action: "submitted report",
    target: "Q4 Analytics",
    time: "8 hours ago",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face",
    initials: "AR",
    type: "success"
  }
];

export function RecentActivity() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-center gap-3">
            <Avatar className="h-8 w-8">
              <AvatarImage src={activity.avatar} />
              <AvatarFallback>{activity.initials}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm">
                <span className="font-medium">{activity.user}</span>{" "}
                {activity.action}{" "}
                <span className="font-medium">{activity.target}</span>
              </p>
              <p className="text-xs text-muted-foreground">{activity.time}</p>
            </div>
            <Badge 
              variant={
                activity.type === "success" ? "default" : 
                activity.type === "warning" ? "secondary" : 
                "outline"
              }
              className="text-xs"
            >
              {activity.type}
            </Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}