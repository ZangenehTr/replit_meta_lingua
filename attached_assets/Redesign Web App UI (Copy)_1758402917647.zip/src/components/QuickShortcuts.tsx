import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { 
  CheckSquare, 
  Mic, 
  Video, 
  Award, 
  CalendarDays,
  ChevronRight 
} from "lucide-react";

const shortcuts = [
  {
    icon: CheckSquare,
    label: "Daily Tasks",
    count: 3,
    gradient: "bg-gradient-to-r from-blue-400 to-cyan-500"
  },
  {
    icon: Mic,
    label: "Speaking Practice",
    count: 2,
    gradient: "bg-gradient-to-r from-green-400 to-emerald-500"
  },
  {
    icon: Video,
    label: "Live Sessions",
    count: 5,
    gradient: "bg-gradient-to-r from-purple-400 to-violet-500"
  },
  {
    icon: Award,
    label: "Achievements",
    count: 12,
    gradient: "bg-gradient-to-r from-yellow-400 to-orange-500"
  },
  {
    icon: CalendarDays,
    label: "Schedule",
    count: 8,
    gradient: "bg-gradient-to-r from-red-400 to-pink-500"
  }
];

export function QuickShortcuts() {
  return (
    <Card className="solid-card relative overflow-hidden">
      <div className="absolute top-0 left-0 w-20 h-20 bg-gradient-to-br from-indigo-400 to-transparent opacity-20 rounded-full"></div>
      <CardContent className="p-5">
        <div className="mb-5">
          <h3 className="font-bold text-xl text-card-foreground">Quick Actions</h3>
          <p className="text-sm text-muted-foreground font-medium">Instant access to your tools</p>
        </div>
        <div className="grid grid-cols-1 gap-3">
          {shortcuts.map((shortcut) => {
            const IconComponent = shortcut.icon;
            return (
              <Button
                key={shortcut.label}
                variant="ghost"
                className="flex items-center justify-between p-4 h-auto hover:bg-gradient-to-r hover:from-pink-50 hover:to-purple-50 rounded-2xl text-card-foreground transition-all duration-300 hover:scale-102 group solid-card-elevated border-0"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-2xl ${shortcut.gradient} shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <IconComponent className="h-5 w-5 text-white" />
                  </div>
                  <span className="font-bold text-base">{shortcut.label}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold bg-gradient-to-r from-pink-500 to-purple-500 text-white px-3 py-1 rounded-full shadow-md">
                    {shortcut.count}
                  </span>
                  <ChevronRight className="h-5 w-5 text-pink-500 group-hover:translate-x-1 transition-transform duration-300" />
                </div>
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}