import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { TrendingUp, Award, Clock, BarChart3 } from "lucide-react";

const achievements = [
  {
    icon: TrendingUp,
    label: "Learning Streak",
    value: "15 days",
    color: "text-green-600",
    bgColor: "bg-gradient-to-r from-green-400 to-emerald-500"
  },
  {
    icon: Award,
    label: "XP Earned",
    value: "+450 XP",
    color: "text-purple-600",
    bgColor: "bg-gradient-to-r from-purple-400 to-violet-500"
  },
  {
    icon: Clock,
    label: "Today's Time",
    value: "2.5h",
    color: "text-blue-600", 
    bgColor: "bg-gradient-to-r from-blue-400 to-cyan-500"
  },
  {
    icon: BarChart3,
    label: "Weekly Total",
    value: "18.2h",
    color: "text-orange-600",
    bgColor: "bg-gradient-to-r from-orange-400 to-red-500"
  }
];

export function RecentAchievements() {
  return (
    <Card className="solid-card relative overflow-hidden">
      <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-yellow-400 to-transparent opacity-20 rounded-full"></div>
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-bold text-card-foreground">Recent Achievements</CardTitle>
        <p className="text-sm text-muted-foreground font-medium">Your learning progress</p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {achievements.map((achievement) => {
            const IconComponent = achievement.icon;
            return (
              <div key={achievement.label} className="solid-card-elevated rounded-2xl p-4 text-center hover:scale-105 transition-transform duration-300 bg-gradient-to-br from-white to-gray-50">
                <div className={`w-12 h-12 rounded-2xl ${achievement.bgColor} flex items-center justify-center mx-auto mb-3 shadow-lg`}>
                  <IconComponent className="h-6 w-6 text-white" />
                </div>
                <div className="text-xl font-bold text-card-foreground mb-1">{achievement.value}</div>
                <div className="text-xs text-muted-foreground font-bold">{achievement.label}</div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}