import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "./ui/accordion";
import { Calendar, Clock, Users } from "lucide-react";

const upcomingClasses = [
  {
    id: 1,
    title: "Business English Conversation",
    instructor: "Sarah Johnson",
    time: "Today, 2:00 PM",
    duration: "60 min",
    students: 8,
    level: "Intermediate"
  },
  {
    id: 2,
    title: "IELTS Writing Workshop",
    instructor: "Michael Chen",
    time: "Tomorrow, 10:00 AM",
    duration: "90 min",
    students: 12,
    level: "Advanced"
  },
  {
    id: 3,
    title: "Grammar Fundamentals",
    instructor: "Emma Davis",
    time: "Friday, 3:30 PM",
    duration: "45 min",
    students: 15,
    level: "Beginner"
  },
  {
    id: 4,
    title: "Pronunciation Practice",
    instructor: "David Wilson",
    time: "Saturday, 11:00 AM",
    duration: "45 min",
    students: 10,
    level: "Intermediate"
  },
  {
    id: 5,
    title: "Speaking Confidence",
    instructor: "Lisa Brown",
    time: "Sunday, 4:00 PM",
    duration: "60 min",
    students: 6,
    level: "Beginner"
  }
];

export function MyClasses() {
  const todayClasses = upcomingClasses.slice(0, 2);
  const upcomingMoreClasses = upcomingClasses.slice(2);

  return (
    <Card className="solid-card text-foreground relative overflow-hidden">
      <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-blue-400 to-transparent opacity-20 rounded-full"></div>
      <CardHeader className="pb-3">
        <div>
          <CardTitle className="text-xl font-bold text-foreground">My Classes</CardTitle>
          <p className="text-sm text-muted-foreground font-medium">Upcoming registered sessions</p>
        </div>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full space-y-4">
          {/* Today's Classes */}
          <AccordionItem value="today" className="border-none">
            <AccordionTrigger className="rounded-2xl bg-gradient-to-r from-blue-50 to-purple-50 px-4 py-3 hover:no-underline hover:bg-gradient-to-r hover:from-blue-100 hover:to-purple-100 transition-all duration-300">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full animate-pulse"></div>
                <span className="font-bold text-foreground">Today's Classes</span>
                <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 text-xs font-bold px-2 py-1">
                  {todayClasses.length}
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="pb-4">
              <div className="space-y-4 mt-4">
                {todayClasses.map((classItem) => (
                  <div 
                    key={classItem.id} 
                    className="solid-card-elevated rounded-2xl p-4 hover:scale-102 transition-all duration-300 bg-gradient-to-br from-white to-blue-50"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                      <div className="flex-1">
                        <h4 className="font-bold text-foreground mb-2">{classItem.title}</h4>
                        <p className="text-sm text-muted-foreground mb-3 font-medium">with {classItem.instructor}</p>
                        <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                          <div className="flex items-center gap-2 bg-white/70 px-3 py-1 rounded-full">
                            <Calendar className="h-4 w-4 text-blue-600" />
                            <span className="font-bold">{classItem.time}</span>
                          </div>
                          <div className="flex items-center gap-2 bg-white/70 px-3 py-1 rounded-full">
                            <Clock className="h-4 w-4 text-green-600" />
                            <span className="font-bold">{classItem.duration}</span>
                          </div>
                          <div className="flex items-center gap-2 bg-white/70 px-3 py-1 rounded-full">
                            <Users className="h-4 w-4 text-purple-600" />
                            <span className="font-bold">{classItem.students}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col sm:items-end gap-3 w-full sm:w-auto">
                        <Badge className="bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0 text-sm font-bold px-3 py-2 self-center sm:self-end">
                          {classItem.level}
                        </Badge>
                        <Button size="sm" className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white rounded-2xl text-sm font-bold px-4 py-2 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 w-full sm:w-auto">
                          Join Now
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Upcoming Classes */}
          {upcomingMoreClasses.length > 0 && (
            <AccordionItem value="upcoming" className="border-none">
              <AccordionTrigger className="rounded-2xl bg-gradient-to-r from-orange-50 to-pink-50 px-4 py-3 hover:no-underline hover:bg-gradient-to-r hover:from-orange-100 hover:to-pink-100 transition-all duration-300">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-gradient-to-r from-orange-400 to-pink-500 rounded-full"></div>
                  <span className="font-bold text-foreground">More Classes</span>
                  <Badge className="bg-gradient-to-r from-orange-500 to-pink-600 text-white border-0 text-xs font-bold px-2 py-1">
                    {upcomingMoreClasses.length}
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-4">
                <div className="space-y-4 mt-4">
                  {upcomingMoreClasses.map((classItem) => (
                    <div 
                      key={classItem.id} 
                      className="solid-card-elevated rounded-2xl p-4 hover:scale-102 transition-all duration-300 bg-gradient-to-br from-white to-orange-50"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                        <div className="flex-1">
                          <h4 className="font-bold text-foreground mb-2">{classItem.title}</h4>
                          <p className="text-sm text-muted-foreground mb-3 font-medium">with {classItem.instructor}</p>
                          <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                            <div className="flex items-center gap-2 bg-white/70 px-3 py-1 rounded-full">
                              <Calendar className="h-4 w-4 text-blue-600" />
                              <span className="font-bold">{classItem.time}</span>
                            </div>
                            <div className="flex items-center gap-2 bg-white/70 px-3 py-1 rounded-full">
                              <Clock className="h-4 w-4 text-green-600" />
                              <span className="font-bold">{classItem.duration}</span>
                            </div>
                            <div className="flex items-center gap-2 bg-white/70 px-3 py-1 rounded-full">
                              <Users className="h-4 w-4 text-purple-600" />
                              <span className="font-bold">{classItem.students}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col sm:items-end gap-3 w-full sm:w-auto">
                          <Badge className="bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0 text-sm font-bold px-3 py-2 self-center sm:self-end">
                            {classItem.level}
                          </Badge>
                          <Button size="sm" className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white rounded-2xl text-sm font-bold px-4 py-2 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 w-full sm:w-auto">
                            Join Now
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          )}
        </Accordion>
      </CardContent>
    </Card>
  );
}