import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Target, Trophy, Clock, Zap } from "lucide-react";

const dailyChallenge = {
  title: "Word Warrior Challenge 🗡️",
  description: "Master 15 fire business terms and flex them in sentences",
  progress: 8,
  total: 15,
  timeLeft: "14h 32m",
  reward: "+50 XP ✨",
  difficulty: "Getting Spicy 🌶️"
};

export function DailyChallenge() {
  return (
    <Card className="solid-card relative overflow-hidden">
      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-yellow-400 to-transparent opacity-30 rounded-full"></div>
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-bold text-card-foreground flex items-center gap-2">
          <Target className="h-6 w-6 text-red-500" />
          Daily Quest! 🎮
        </CardTitle>
        <p className="text-sm text-muted-foreground font-medium">Today's main character moment</p>
      </CardHeader>
      <CardContent>
        <div className="solid-card-elevated rounded-2xl p-5 space-y-4 bg-gradient-to-br from-orange-50 to-red-50">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h4 className="font-bold text-card-foreground mb-2 text-lg">{dailyChallenge.title}</h4>
              <p className="text-sm text-muted-foreground mb-4 font-medium">{dailyChallenge.description}</p>
              
              <div className="flex items-center gap-3 mb-3">
                <Badge className="bg-gradient-to-r from-orange-400 to-red-500 text-white border-0 text-sm font-bold px-3 py-1">
                  {dailyChallenge.difficulty}
                </Badge>
                <div className="flex items-center gap-1 text-sm text-muted-foreground bg-white/70 px-3 py-1 rounded-full">
                  <Clock className="h-4 w-4" />
                  <span className="font-bold">{dailyChallenge.timeLeft} left ⏰</span>
                </div>
              </div>
            </div>
            
            <div className="text-right">
              <div className="p-3 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl mb-2 shadow-lg float">
                <Trophy className="h-6 w-6 text-white" />
              </div>
              <div className="text-sm font-bold text-yellow-600 bg-yellow-100 px-2 py-1 rounded-lg">{dailyChallenge.reward}</div>
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground font-bold">You're crushing it! 💪</span>
              <span className="text-card-foreground font-bold text-lg">{dailyChallenge.progress}/{dailyChallenge.total}</span>
            </div>
            <div className="relative">
              <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 rounded-full transition-all duration-500 flex items-center justify-end pr-1 relative"
                  style={{ width: `${(dailyChallenge.progress / dailyChallenge.total) * 100}%` }}
                >
                  <Zap className="h-3 w-3 text-white" />
                  <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full"></div>
                </div>
              </div>
            </div>
          </div>
          
          <Button className="w-full bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 hover:from-pink-600 hover:via-purple-600 hover:to-blue-600 text-white rounded-full text-lg font-bold py-4 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
            Keep Going! 🚀
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}