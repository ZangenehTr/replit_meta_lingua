import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Mic, Headphones, BookOpen, PenTool } from "lucide-react";

const skills = [
  { 
    name: "Speaking", 
    icon: Mic,
    level: "B2", 
    progress: 82, 
    color: "bg-red-500/40",
    iconColor: "text-red-300" 
  },
  { 
    name: "Listening", 
    icon: Headphones,
    level: "B2", 
    progress: 78, 
    color: "bg-blue-500/40",
    iconColor: "text-blue-300" 
  },
  { 
    name: "Reading", 
    icon: BookOpen,
    level: "B1", 
    progress: 71, 
    color: "bg-green-500/40",
    iconColor: "text-green-300" 
  },
  { 
    name: "Writing", 
    icon: PenTool,
    level: "B1", 
    progress: 65, 
    color: "bg-purple-500/40",
    iconColor: "text-purple-300" 
  },
];

export function SkillProgress() {
  return (
    <Card className="solid-card relative overflow-hidden">
      <div className="absolute top-0 left-0 w-20 h-20 bg-gradient-to-br from-cyan-400 to-transparent opacity-20 rounded-full"></div>
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-bold text-card-foreground">Skill Progress</CardTitle>
        <p className="text-sm text-muted-foreground font-medium">Your language proficiency journey</p>
      </CardHeader>
      <CardContent className="space-y-5">
        {skills.map((skill) => (
          <div key={skill.name} className="solid-card-elevated rounded-2xl p-4 hover:scale-102 transition-all duration-300">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-gradient-to-r from-pink-400 to-purple-500 rounded-2xl shadow-lg">
                  <skill.icon className="h-5 w-5 text-white" />
                </div>
                <span className="font-bold text-card-foreground">{skill.name}</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-0 font-bold">
                  {skill.level}
                </Badge>
                <span className="text-sm font-bold text-muted-foreground">{skill.progress}%</span>
              </div>
            </div>
            <div className="relative">
              <div className="h-3 bg-gray-200 rounded-full overflow-hidden shadow-inner">
                <div 
                  className="h-full bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 rounded-full transition-all duration-500 shadow-sm"
                  style={{ width: `${skill.progress}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}