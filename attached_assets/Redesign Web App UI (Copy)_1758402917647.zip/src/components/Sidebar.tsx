import { 
  BarChart3, 
  Calendar, 
  FileText, 
  Home, 
  Settings, 
  Users, 
  Zap 
} from "lucide-react";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";

const navItems = [
  { icon: Home, label: "Overview", active: true },
  { icon: BarChart3, label: "Analytics" },
  { icon: Users, label: "Customers" },
  { icon: FileText, label: "Projects" },
  { icon: Calendar, label: "Calendar" },
];

const bottomItems = [
  { icon: Zap, label: "Upgrade" },
  { icon: Settings, label: "Settings" },
];

export function Sidebar() {
  return (
    <aside className="w-64 border-r bg-sidebar px-3 py-4 flex flex-col">
      <div className="flex items-center gap-2 px-3 mb-6">
        <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
          <Zap className="h-4 w-4 text-primary-foreground" />
        </div>
        <span className="font-medium text-sidebar-foreground">Workspace</span>
      </div>
      
      <nav className="space-y-1 flex-1">
        {navItems.map((item) => (
          <Button
            key={item.label}
            variant={item.active ? "secondary" : "ghost"}
            className="w-full justify-start gap-3 text-sidebar-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent"
            size="sm"
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </Button>
        ))}
      </nav>
      
      <Separator className="my-4" />
      
      <div className="space-y-1">
        {bottomItems.map((item) => (
          <Button
            key={item.label}
            variant="ghost"
            className="w-full justify-start gap-3 text-sidebar-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent"
            size="sm"
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </Button>
        ))}
      </div>
    </aside>
  );
}