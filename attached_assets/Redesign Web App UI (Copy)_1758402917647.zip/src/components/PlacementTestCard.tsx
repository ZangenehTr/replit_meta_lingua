import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Clock, Users, Target } from "lucide-react";

export function PlacementTestCard() {
  return (
    <Card className="solid-card text-foreground overflow-hidden relative">
      <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-pink-400 to-transparent opacity-20 rounded-full"></div>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-bold text-foreground">Placement Test</CardTitle>
            <p className="text-sm text-muted-foreground">Discover your level</p>
          </div>
          <div className="p-2 bg-gradient-to-r from-pink-400 to-purple-500 rounded-xl shadow-lg float">
            <Target className="h-5 w-5 text-white" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="solid-card-elevated rounded-2xl p-4 bg-gradient-to-br from-blue-50 to-purple-50">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-bold text-foreground">Level Assessment</h4>
            <Badge className="bg-gradient-to-r from-green-400 to-emerald-500 text-white border-0 text-sm font-bold px-2 py-1">
              FREE
            </Badge>
          </div>
          
          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
            <div className="flex items-center gap-2 bg-white/70 px-2 py-1 rounded-full">
              <Clock className="h-3 w-3" />
              <span className="font-medium">25 mins</span>
            </div>
            <div className="flex items-center gap-2 bg-white/70 px-2 py-1 rounded-full">
              <Users className="h-3 w-3" />
              <span className="font-medium">50 questions</span>
            </div>
          </div>
          
          <Button className="w-full bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 hover:from-pink-600 hover:via-purple-600 hover:to-blue-600 text-white rounded-full font-bold py-3 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
            Start Test
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}