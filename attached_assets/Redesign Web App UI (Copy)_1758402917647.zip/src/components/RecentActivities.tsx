import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { CheckCircle, BookOpen, Headphones, PenTool } from "lucide-react";

const activities = [
  {
    id: 1,
    icon: CheckCircle,
    title: "Completed Lesson 3.1",
    subject: "Grammar: Present Perfect",
    time: "2 hours ago",
    type: "completed",
    score: "92%"
  },
  {
    id: 2,
    icon: Headphones,
    title: "Listening Exercise",
    subject: "Business Conversations",
    time: "4 hours ago",
    type: "practice",
    score: "78%"
  },
  {
    id: 3,
    icon: PenTool,
    title: "Writing Assignment",
    subject: "Essay: Climate Change",
    time: "1 day ago",
    type: "submitted",
    score: "85%"
  },
  {
    id: 4,
    icon: BookOpen,
    title: "Vocabulary Quiz",
    subject: "Advanced Business Terms",
    time: "2 days ago",
    type: "completed",
    score: "96%"
  }
];

export function RecentActivities() {
  return (
    <Card className="glass text-white border-white/30 shadow-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg text-white">Recent Activities</CardTitle>
        <p className="text-sm text-white/70">Your latest learning activities</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start gap-3">
            <div className="p-2 glass rounded-lg mt-0.5">
              <activity.icon className="h-4 w-4 text-white/70" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <p className="text-sm font-medium text-white">{activity.title}</p>
                  <p className="text-xs text-white/70">{activity.subject}</p>
                  <p className="text-xs text-white/70 mt-1">{activity.time}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <Badge 
                    variant="secondary"
                    className={`text-xs glass text-white border-white/30 ${
                      activity.type === "completed" ? "bg-green-500/20" : "bg-white/10"
                    }`}
                  >
                    {activity.type}
                  </Badge>
                  <span className="text-xs font-medium text-green-300">{activity.score}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}