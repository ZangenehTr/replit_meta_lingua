import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Carousel, CarouselContent, CarouselItem } from "./ui/carousel";
import { Star, MessageCircle, Crown } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const onlineTeachers = [
  {
    id: 1,
    name: "Sarah Mitchell",
    image: "https://images.unsplash.com/photo-1750926013469-9d8f680d8aff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWRkbGUlMjBhZ2VkJTIwd29tYW4lMjB0ZWFjaGVyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzU4NDAxOTY2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    expertise: "Business English, IELTS",
    rank: "Expert",
    rating: 4.9,
    reviews: 234,
    available: true,
    rate: "$25/hour"
  },
  {
    id: 2,
    name: "Michael Chen",
    image: "https://images.unsplash.com/photo-1604346382498-34e8c19df705?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwdGVhY2hlciUyMHByb2Zlc3Npb25hbCUyMGhlYWRzaG90fGVufDF8fHx8MTc1ODQwMTk1Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    expertise: "Conversation, Pronunciation",
    rank: "Master",
    rating: 4.8,
    reviews: 189,
    available: false,
    rate: "$30/hour"
  },
  {
    id: 3,
    name: "Emma Rodriguez",
    image: "https://images.unsplash.com/photo-1746513534315-caa52d3f462c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB3b21hbiUyMHRlYWNoZXIlMjBzbWlsaW5nfGVufDF8fHx8MTc1ODQwMTk2MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    expertise: "Grammar, Writing",
    rank: "Expert",
    rating: 4.7,
    reviews: 156,
    available: true,
    rate: "$22/hour"
  },
  {
    id: 4,
    name: "James Wilson",
    image: "https://images.unsplash.com/photo-1707676602290-acfdedc6b41d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibGFjayUyMG1hbGUlMjB0ZWFjaGVyJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1ODQwMTk2M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    expertise: "Academic English, TOEFL",
    rank: "Master",
    rating: 4.9,
    reviews: 298,
    available: true,
    rate: "$35/hour"
  }
];

export function OnlineTeachers() {
  return (
    <Card className="solid-card text-foreground relative overflow-hidden">
      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-purple-400 to-transparent opacity-20 rounded-full"></div>
      <CardHeader className="pb-3">
        <div>
          <CardTitle className="text-xl font-bold text-foreground">Call and Learn 24/7</CardTitle>
          <p className="text-sm text-muted-foreground font-medium">Expert teachers ready to help</p>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="px-6 pb-6">
          <Carousel
            opts={{
              align: "start",
              dragFree: true,
            }}
            className="w-full"
          >
            <CarouselContent className="-ml-1">
              {onlineTeachers.map((teacher) => (
                <CarouselItem key={teacher.id} className="pl-1 basis-[90%]">
                  <div className="p-1">
                    <div className="solid-card-elevated rounded-2xl p-5 hover:scale-102 transition-all duration-300">
                      <div className="flex flex-col items-center text-center gap-4">
                        <div className="relative">
                          <div className="w-20 h-20 rounded-2xl overflow-hidden shadow-lg ring-4 ring-white/50">
                            <ImageWithFallback
                              src={teacher.image}
                              alt={teacher.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          {teacher.available && (
                            <div className="absolute -bottom-2 -right-2 w-6 h-6 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full border-3 border-white shadow-lg flex items-center justify-center">
                              <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                            </div>
                          )}
                        </div>
                        
                        <div className="space-y-3">
                          <div>
                            <h4 className="font-bold text-foreground text-lg">{teacher.name}</h4>
                            <p className="text-sm text-muted-foreground font-medium">{teacher.expertise}</p>
                          </div>
                          
                          <div className="flex flex-col items-center gap-2">
                            <div className="flex items-center gap-1 bg-yellow-50 px-3 py-1 rounded-full">
                              <Star className="h-4 w-4 fill-current text-yellow-500" />
                              <span className="text-sm font-bold text-foreground">{teacher.rating}</span>
                              <span className="text-xs text-muted-foreground font-bold">({teacher.reviews})</span>
                            </div>
                            <Badge className={`text-sm font-bold flex items-center gap-1 px-3 py-1 ${
                              teacher.rank === "Master" 
                                ? "bg-gradient-to-r from-purple-500 to-violet-600 text-white border-0" 
                                : "bg-gradient-to-r from-blue-500 to-cyan-600 text-white border-0"
                            }`}>
                              <Crown className="h-4 w-4" />
                              {teacher.rank}
                            </Badge>
                          </div>
                          
                          <div className="flex flex-col items-center gap-3">
                            <span className={`text-sm font-bold flex items-center gap-2 px-3 py-1 rounded-full ${
                              teacher.available ? "text-green-600 bg-green-100" : "text-red-600 bg-red-100"
                            }`}>
                              <div className={`w-3 h-3 rounded-full ${
                                teacher.available ? "bg-green-500" : "bg-red-500"
                              } ${teacher.available ? "animate-pulse" : ""}`}></div>
                              {teacher.available ? "Online" : "Busy"}
                            </span>
                            
                            <Button 
                              size="sm" 
                              disabled={!teacher.available}
                              className={`rounded-2xl flex items-center gap-2 text-sm px-6 py-2 font-bold transition-all duration-300 w-full ${
                                teacher.available 
                                  ? "bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg hover:shadow-xl hover:scale-105" 
                                  : "bg-gray-200 text-gray-400 cursor-not-allowed"
                              }`}
                            >
                              <MessageCircle className="h-4 w-4" />
                              <span>{teacher.available ? "Learn NOW!" : "Offline"}</span>
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
        </div>
      </CardContent>
    </Card>
  );
}