import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";

const tabs = [
  { label: "Overview", active: true },
  { label: "Lessons", active: false },
  { label: "Practice", active: false },
  { label: "Tests", active: false },
  { label: "Vocabulary", active: false },
  { label: "Grammar", active: false },
];

export function TopTabs() {
  return (
    <div className="glass border-b border-white/20 sticky top-[72px] z-40">
      <ScrollArea className="w-full">
        <div className="flex space-x-1 p-4 min-w-max">
          {tabs.map((tab) => (
            <Button
              key={tab.label}
              variant={tab.active ? "default" : "ghost"}
              size="sm"
              className={`whitespace-nowrap rounded-full ${
                tab.active 
                  ? "bg-white/20 text-white backdrop-blur-sm border border-white/30" 
                  : "text-white/80 hover:text-white hover:bg-white/10"
              }`}
            >
              {tab.label}
            </Button>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}