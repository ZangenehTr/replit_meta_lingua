import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";

const weeklyData = [
  { day: "Mon", hours: 2.5 },
  { day: "Tue", hours: 1.8 },
  { day: "Wed", hours: 3.2 },
  { day: "Thu", hours: 2.1 },
  { day: "Fri", hours: 2.8 },
  { day: "Sat", hours: 4.1 },
  { day: "Sun", hours: 1.5 },
];

export function WeeklyProgress() {
  return (
    <Card className="glass text-white border-white/30 shadow-2xl">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg text-white">Weekly Progress</CardTitle>
          <div className="text-sm text-white/70">This week</div>
        </div>
        <div className="flex items-center gap-4 mt-2">
          <div className="text-2xl font-semibold text-white">18.0</div>
          <div className="text-sm text-white/70">hours studied</div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={weeklyData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
            <XAxis 
              dataKey="day" 
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: 'rgba(255, 255, 255, 0.7)' }}
            />
            <YAxis hide />
            <Bar 
              dataKey="hours" 
              fill="rgba(255, 255, 255, 0.4)" 
              radius={[4, 4, 0, 0]}
              maxBarSize={32}
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}