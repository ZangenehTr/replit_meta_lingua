import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import { Clock, Phone, Star, ChevronRight } from "lucide-react";

// Mock data - this would determine which component to show
const hasActivePackage = true;

const activePackage = {
  name: "Premium CallerN Package",
  totalMinutes: 240,
  usedMinutes: 85,
  remainingMinutes: 155,
  expiryDate: "Dec 25, 2024"
};

const availablePackages = [
  {
    id: 1,
    name: "Starter Package",
    minutes: 100,
    price: "$29",
    duration: "30 days",
    popular: false
  },
  {
    id: 2,
    name: "Standard Package", 
    minutes: 180,
    price: "$49",
    duration: "30 days",
    popular: false
  },
  {
    id: 3,
    name: "Premium Package",
    minutes: 240,
    price: "$69",
    duration: "30 days",
    popular: true
  },
  {
    id: 4,
    name: "Pro Package",
    minutes: 360,
    price: "$99",
    duration: "30 days",
    popular: false
  }
];

export function CallerNStatus() {
  if (hasActivePackage) {
    return (
      <Card className="solid-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-card-foreground flex items-center gap-2">
            <Phone className="h-5 w-5" />
            Active CallerN Class
          </CardTitle>
          <p className="text-sm text-muted-foreground">Your current speaking package</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="solid-card-elevated rounded-lg p-4">
            <h4 className="font-medium text-card-foreground mb-3">{activePackage.name}</h4>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Remaining Minutes</span>
                <span className="font-semibold text-green-600">{activePackage.remainingMinutes} min</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Used This Month</span>
                <span className="font-semibold text-card-foreground">{activePackage.usedMinutes} min</span>
              </div>
              
              <div className="relative">
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-green-500 rounded-full transition-all duration-300"
                    style={{ 
                      width: `${((activePackage.totalMinutes - activePackage.remainingMinutes) / activePackage.totalMinutes) * 100}%` 
                    }}
                  />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>0</span>
                  <span>{activePackage.totalMinutes} min</span>
                </div>
              </div>
              
              <div className="flex justify-between items-center pt-2">
                <span className="text-sm text-muted-foreground">Expires: {activePackage.expiryDate}</span>
                <Button size="sm" className="bg-primary hover:bg-primary/90 text-white rounded-full">
                  Renew Package
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="solid-card">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg text-card-foreground flex items-center gap-2">
          <Phone className="h-5 w-5" />
          CallerN Packages
        </CardTitle>
        <p className="text-sm text-muted-foreground">Choose your speaking practice package</p>
      </CardHeader>
      <CardContent>
        <ScrollArea className="w-full">
          <div className="flex gap-4 pb-4">
            {availablePackages.map((pkg) => (
              <div key={pkg.id} className="solid-card-elevated rounded-xl p-4 min-w-[200px] relative">
                {pkg.popular && (
                  <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-yellow-100 text-yellow-700 border-yellow-200">
                    <Star className="h-3 w-3 mr-1" />
                    Popular
                  </Badge>
                )}
                
                <div className="text-center space-y-3 pt-2">
                  <div className="p-3 bg-muted rounded-full w-fit mx-auto">
                    <Clock className="h-6 w-6 text-muted-foreground" />
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-card-foreground mb-1">{pkg.name}</h4>
                    <div className="text-2xl font-bold text-card-foreground">{pkg.minutes}</div>
                    <div className="text-xs text-muted-foreground">minutes</div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-lg font-semibold text-card-foreground">{pkg.price}</div>
                    <div className="text-xs text-muted-foreground">{pkg.duration}</div>
                  </div>
                  
                  <Button 
                    size="sm" 
                    className={`w-full rounded-full ${
                      pkg.popular 
                        ? "bg-yellow-500 hover:bg-yellow-600 text-white" 
                        : "bg-primary hover:bg-primary/90 text-white"
                    }`}
                  >
                    Select Package
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}