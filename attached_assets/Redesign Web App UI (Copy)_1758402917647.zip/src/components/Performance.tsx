import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { TrendingUp, Clock, Zap, Target } from "lucide-react";

const stats = [
  {
    icon: TrendingUp,
    label: "Streak",
    value: "12 days",
    color: "text-green-300",
    bgColor: "bg-green-500/20"
  },
  {
    icon: Clock,
    label: "Study Time",
    value: "2.5h",
    color: "text-blue-300", 
    bgColor: "bg-blue-500/20"
  },
  {
    icon: Zap,
    label: "XP Points",
    value: "1,250",
    color: "text-purple-300",
    bgColor: "bg-purple-500/20"
  },
  {
    icon: Target,
    label: "Accuracy",
    value: "84%",
    color: "text-orange-300",
    bgColor: "bg-orange-500/20"
  }
];

export function Performance() {
  return (
    <Card className="glass text-white border-white/30 shadow-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg text-white">Performance</CardTitle>
        <p className="text-sm text-white/70">Today's achievements</p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {stats.map((stat) => (
            <div key={stat.label} className="flex items-center gap-3">
              <div className={`p-2 rounded-lg glass ${stat.bgColor}`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
              <div>
                <div className="text-lg font-semibold text-white">{stat.value}</div>
                <div className="text-xs text-white/70">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}