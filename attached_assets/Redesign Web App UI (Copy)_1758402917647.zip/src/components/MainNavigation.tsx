import { Home, GraduationCap, Video, Bot, Headphones } from "lucide-react";
import { Button } from "./ui/button";

const navItems = [
  { icon: Home, label: "Home", active: true },
  { icon: GraduationCap, label: "Classes", active: false },
  { icon: Video, label: "CallerN", active: false },
  { icon: Bot, label: "Lexi", active: false },
  { icon: Headphones, label: "Support", active: false },
];

export function MainNavigation() {
  return (
    <nav className="fixed bottom-8 left-4 right-4 solid-card-elevated border-t-0 max-w-md mx-auto rounded-3xl backdrop-blur-xl">
      <div className="flex items-center justify-around py-4 px-2">
        {navItems.map((item) => {
          const IconComponent = item.icon;
          return (
            <Button
              key={item.label}
              variant="ghost"
              size="sm"
              className={`flex flex-col items-center gap-1 p-3 h-16 w-16 rounded-2xl transition-all duration-300 ${
                item.active 
                  ? "bg-gradient-to-r from-pink-500 to-purple-500 text-white shadow-lg scale-110" 
                  : "text-muted-foreground hover:bg-gradient-to-r hover:from-pink-100 hover:to-purple-100 hover:text-pink-600 hover:scale-105"
              }`}
            >
              <IconComponent className="h-5 w-5" />
              <span className="text-xs font-bold">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
}