import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";

const skills = [
  { name: "Reading", level: "B2", progress: 78, color: "bg-blue-500" },
  { name: "Writing", level: "B1", progress: 65, color: "bg-green-500" },
  { name: "Speaking", level: "B2", progress: 82, color: "bg-purple-500" },
  { name: "Listening", level: "B1", progress: 71, color: "bg-orange-500" },
];

export function LanguageSkills() {
  return (
    <Card className="glass text-white border-white/30 shadow-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg text-white">Language Skills</CardTitle>
        <p className="text-sm text-white/70">Your current proficiency levels</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {skills.map((skill) => (
          <div key={skill.name} className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-white">{skill.name}</span>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs glass text-white border-white/30">
                  {skill.level}
                </Badge>
                <span className="text-xs text-white/70">{skill.progress}%</span>
              </div>
            </div>
            <div className="h-2 glass rounded-full overflow-hidden">
              <div 
                className="h-full bg-white/40 rounded-full transition-all duration-300"
                style={{ width: `${skill.progress}%` }}
              />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}