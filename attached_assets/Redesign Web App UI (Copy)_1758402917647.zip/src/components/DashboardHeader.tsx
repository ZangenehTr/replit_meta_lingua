import { Bell, Menu, Wallet, Crown, Star } from "lucide-react";
import { Button } from "./ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "./ui/avatar";
import { Badge } from "./ui/badge";

export function DashboardHeader() {
  return (
    <header className="solid-card-elevated text-foreground px-3 py-2 sticky top-0 z-50 m-4 bounce-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" className="text-foreground hover:bg-gradient-to-r hover:from-pink-500 hover:to-violet-500 hover:text-white rounded-full transition-all duration-300 p-2">
            <Menu className="h-4 w-4" />
          </Button>
          <h1 className="text-lg font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
            Meta Lingua
          </h1>
        </div>
        
        <div className="flex items-center gap-2">
          <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0 flex items-center gap-1 px-2 py-1 text-sm font-bold">
            <Crown className="h-3 w-3" />
            Gold
          </Badge>
          
          <Button variant="ghost" size="sm" className="text-foreground hover:bg-green-100 hover:text-green-600 flex items-center gap-2 rounded-full transition-all duration-300 p-2">
            <Wallet className="h-4 w-4" />
            <span className="text-sm font-bold hidden sm:inline">$25.50</span>
          </Button>
          
          <Button variant="ghost" size="sm" className="text-foreground hover:bg-red-100 hover:text-red-600 relative rounded-full transition-all duration-300 float p-2">
            <Bell className="h-4 w-4" />
            <div className="absolute -top-1 -right-1 h-3 w-3 bg-gradient-to-r from-red-400 to-pink-500 rounded-full flex items-center justify-center">
              <span className="text-[8px] text-white font-bold">3</span>
            </div>
          </Button>
        </div>
      </div>
      
      {/* User Info Row */}
      <div className="mt-2 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9 ring-2 ring-pink-200 ring-offset-1 rounded-2xl">
            <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b612b786?w=64&h=64&fit=crop&crop=face" className="rounded-2xl" />
            <AvatarFallback className="gen-z-gradient text-white font-bold rounded-2xl">AM</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="font-bold text-foreground text-sm">Hey Anna!</h2>
            <p className="text-xs text-muted-foreground">Ready for today's lessons?</p>
          </div>
        </div>
      </div>
    </header>
  );
}