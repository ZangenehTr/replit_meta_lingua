import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Calendar, Play, FileText, Headphones } from "lucide-react";

const upcomingItems = [
  {
    id: 1,
    icon: Play,
    title: "Video Lesson: Conditional Sentences",
    type: "lesson",
    duration: "15 min",
    difficulty: "Intermediate",
    scheduled: "Today, 3:00 PM"
  },
  {
    id: 2,
    icon: FileText,
    title: "Reading Comprehension Practice",
    type: "exercise",
    duration: "25 min",
    difficulty: "Advanced",
    scheduled: "Tomorrow, 10:00 AM"
  },
  {
    id: 3,
    icon: Headphones,
    title: "Pronunciation Workshop",
    type: "workshop",
    duration: "30 min",
    difficulty: "Beginner",
    scheduled: "Wed, 2:00 PM"
  }
];

export function UpcomingContent() {
  return (
    <Card className="glass text-white border-white/30 shadow-2xl">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg text-white">Upcoming Content</CardTitle>
          <Button variant="ghost" size="sm" className="text-xs text-white/70 hover:text-white hover:bg-white/10">
            View all
          </Button>
        </div>
        <p className="text-sm text-white/70">Scheduled learning activities</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {upcomingItems.map((item) => (
          <div key={item.id} className="flex items-start gap-3 p-3 rounded-lg glass border-white/20">
            <div className="p-2 glass rounded-lg mt-0.5">
              <item.icon className="h-4 w-4 text-white/70" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2 mb-2">
                <h4 className="text-sm font-medium leading-tight text-white">{item.title}</h4>
                <Badge variant="outline" className="text-xs glass text-white border-white/30">
                  {item.duration}
                </Badge>
              </div>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary" className="text-xs glass text-white border-white/30">
                  {item.difficulty}
                </Badge>
                <span className="text-xs text-white/70 capitalize">{item.type}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-xs text-white/70">
                  <Calendar className="h-3 w-3" />
                  {item.scheduled}
                </div>
                <Button variant="ghost" size="sm" className="text-xs h-6 px-2 text-white/70 hover:text-white hover:bg-white/10">
                  Start
                </Button>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}