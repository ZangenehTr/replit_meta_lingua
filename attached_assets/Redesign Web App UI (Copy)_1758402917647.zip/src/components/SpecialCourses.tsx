import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Carousel, CarouselContent, CarouselItem } from "./ui/carousel";
import { Star, Users, Clock } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const specialCourses = [
  {
    id: 1,
    title: "Advanced Business English",
    instructor: "Dr. Sarah Mitchell",
    image: "https://images.unsplash.com/photo-1696960181436-1b6d9576354e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBmZW1hbGUlMjB0ZWFjaGVyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzU4NDAxOTQ5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.9,
    students: 234,
    duration: "8 weeks",
    price: "$149",
    level: "Advanced"
  },
  {
    id: 2,
    title: "IELTS Preparation Master",
    instructor: "Prof. Michael Chen",
    image: "https://images.unsplash.com/photo-1701463387028-3947648f1337?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMG1hbGUlMjBwcm9mZXNzb3IlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NTg0MDE5NTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.8,
    students: 456,
    duration: "12 weeks",
    price: "$199",
    level: "Intermediate"
  },
  {
    id: 3,
    title: "Conversation Mastery",
    instructor: "Emma Rodriguez",
    image: "https://images.unsplash.com/photo-1722963220454-6650d75488ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaXNwYW5pYyUyMHdvbWFuJTIwdGVhY2hlciUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NTg0MDE5NTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.7,
    students: 189,
    duration: "6 weeks",
    price: "$99",
    level: "All Levels"
  }
];

export function SpecialCourses() {
  return (
    <Card className="solid-card relative overflow-hidden">
      <div className="absolute top-0 left-0 w-20 h-20 bg-gradient-to-br from-green-400 to-transparent opacity-20 rounded-full"></div>
      <CardHeader className="pb-3">
        <div>
          <CardTitle className="text-xl font-bold text-card-foreground">Special Courses</CardTitle>
          <p className="text-sm text-muted-foreground font-medium">Expert-led premium programs</p>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="px-6 pb-6">
          <Carousel
            opts={{
              align: "start",
              dragFree: true,
            }}
            className="w-full"
          >
            <CarouselContent className="-ml-1">
              {specialCourses.map((course) => (
                <CarouselItem key={course.id} className="pl-1 basis-[90%]">
                  <div className="p-1">
                    <div className="solid-card-elevated rounded-3xl p-5 hover:scale-105 transition-all duration-300 bg-gradient-to-br from-white to-gray-50">
                      <div className="relative mb-5">
                        <div className="w-full h-48 rounded-2xl overflow-hidden mb-4 shadow-lg ring-2 ring-white/50">
                          <ImageWithFallback
                            src={course.image}
                            alt={course.instructor}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <Badge className="absolute top-3 right-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0 text-sm font-bold px-3 py-2 shadow-lg">
                          {course.level}
                        </Badge>
                      </div>
                      
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-bold text-card-foreground mb-2 text-lg">{course.title}</h4>
                          <p className="text-sm text-muted-foreground font-medium">by {course.instructor}</p>
                        </div>
                        
                        <div className="flex items-center justify-between text-sm text-muted-foreground flex-wrap gap-2">
                          <div className="flex items-center gap-2 bg-yellow-100 px-3 py-1 rounded-full">
                            <Star className="h-4 w-4 fill-current text-yellow-500" />
                            <span className="font-bold">{course.rating}</span>
                          </div>
                          <div className="flex items-center gap-2 bg-blue-100 px-3 py-1 rounded-full">
                            <Users className="h-4 w-4 text-blue-600" />
                            <span className="font-bold">{course.students}</span>
                          </div>
                          <div className="flex items-center gap-2 bg-green-100 px-3 py-1 rounded-full">
                            <Clock className="h-4 w-4 text-green-600" />
                            <span className="font-bold">{course.duration}</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between pt-2 gap-4">
                          <span className="font-bold text-card-foreground text-xl bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">{course.price}</span>
                          <Button size="sm" className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 hover:from-pink-600 hover:via-purple-600 hover:to-blue-600 text-white rounded-2xl px-6 py-3 font-bold text-sm shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 flex-shrink-0">
                            Learn NOW!
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
        </div>
      </CardContent>
    </Card>
  );
}