
  # Redesign Web App UI (Copy)

  This is a code bundle for Redesign Web App UI (Copy). The original project is available at https://www.figma.com/design/c8Jj6vai1kojCv8d54niuQ/Redesign-Web-App-UI--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  